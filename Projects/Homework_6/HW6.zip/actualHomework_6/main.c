//ECE 5380 - Embedded Systems
//HW6
//Author: Joshua Williams
//Co-author: Connor Collins
//
//Description: TSK1 uses SW0 to request the SEM. When it gets the SEM it turns on LED0
//			   TSK1 uses SW1 to release the SEM. When it releases the SEM it turns off LED0
//
//			   TSK2 uses SW3 to request the SEM. When it gets the SEM it turns on LED3
//			   TSK2 uses SW2 to release the SEM. When it releases the SEM it turns off LED3
//
//References: Example source code provided by Dr. Brian Nutter, Texas Tech University
//
//http://www.mosaic-industries.com/embedded-systems/c-ide-software-development/multitasking-real-time-operating-system-rtos/c-programming
//
//-----------------------------------------------------------------------
#include "josh_semcfg.h"
#include "dsk6713_dip.h"
#include "dsk6713_led.h"
#include "dsk6713.h"
#include <swi.h>
#include <sem.h>
#include <tsk.h>

//-----------------------------------------------------------------------
void init(void);
//-----------------------------------------------------------------------

typedef struct _Globals
{
	SEM_Obj *SEM0;

	TSK_Obj *TSK0;
	TSK_Obj *TSK1;
	TSK_Obj *TSK2;

	SWI_Obj *SWI0;

} Globals;

Globals Glo;

//-----------------------------------------------------------------------
void main(void)
{
	init();
}
//-----------------------------------------------------------------------


//-----------------------------------------------------------------------
void init(void)
{
	DSK6713_init();                   	//call BSL to init DSK-EMIF,PLL)
	CSL_init();
	DSK6713_LED_init();  				//init LEDs
	DSK6713_DIP_init();                 //init DIP SWs

	Glo.SEM0 = &SEM0;					// lets you look at SEM contents in debugger

	Glo.TSK0 = &TSK0;					// lets you look at TSK contents in debugger
	Glo.TSK1 = &TSK1;
	Glo.TSK2 = &TSK2;

} // init
//-----------------------------------------------------------------------


//-----------------------------------------------------------------------
void PRD0_ftn(int arg0, int arg1)
{
	//SWI_post(&SWI0);
}
//-----------------------------------------------------------------------


//-----------------------------------------------------------------------

//SW0 request SEM, turn on LED0
//SW1 release SEM, turn off LED0
void TSK0_ftn(int arg0, int arg1)
{
	for(;;)
	{
		SEM_pendBinary(&SEM0, SYS_FOREVER);	//get the sem

		if(DSK6713_DIP_get(0)==0)		//if sw0 is down
		{
			DSK6713_LED_on(0);			//turn on LED

			while(DSK6713_DIP_get(1)==1)
			{
				//wait here until sw1 is no longer up
			}

			DSK6713_LED_off(0);			//sw1 is now down, so turn it off
		}

		SEM_postBinary(&SEM0);				//release the sem
	}

}// TSK0_ftn

//-----------------------------------------------------------------------


//-----------------------------------------------------------------------

//SW3 request SEM, turn on LED3
//SW2 release SEM, turn off LED3
void TSK1_ftn(int arg0, int arg1)
{
	for(;;)
	{
		SEM_pendBinary(&SEM0, SYS_FOREVER);	//get the sem

		if(DSK6713_DIP_get(3)==0) 		//if sw3 is down
		{
			DSK6713_LED_on(3);			//turn on LED

			while(DSK6713_DIP_get(2)==1)
			{
				//wait here until sw2 is no longer up
			}

			DSK6713_LED_off(3);			//sw2 is down now, turn off LED
		}

		SEM_postBinary(&SEM0);				//release the sem
	}

}// TSK1_ftn

//-----------------------------------------------------------------------


//-----------------------------------------------------------------------
//post to restart the whole process
void TSK2_ftn(int arg0, int arg1)
{
	SEM_postBinary(&SEM0);

}// TSK2_ftn
//-----------------------------------------------------------------------
